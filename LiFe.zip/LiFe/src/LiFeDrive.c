#include "LiFeDrive.h"
#include <math.h>

void slow_servo(int port, int start_pos, int end_pos, int time) {
  int interval = 50;
  int curr_pos = start_pos;
  while ((end_pos - curr_pos) * (end_pos - start_pos) > 0) {
    set_servo_position(port, curr_pos);
    curr_pos += (float) {(end_pos - start_pos)} / (float) {(time / interval)};
    msleep(50);
  }
    set_servo_position(port, end_pos);
}

void slow_servo_dual(int port_1, int start_pos_1, int end_pos_1, 
                     int port_2, int start_pos_2, int end_pos_2, int time) {
  int interval = 50;
  int curr_pos_1 = start_pos_1;
  int curr_pos_2 = start_pos_2;
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
    set_servo_position(port_1, curr_pos_1);
    set_servo_position(port_2, curr_pos_2);
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    msleep(50);
  }
    set_servo_position(port_1, end_pos_1);
    set_servo_position(port_2, end_pos_2);
}

void slow_servo_tri(int port_1, int start_pos_1, int end_pos_1, 
                     int port_2, int start_pos_2, int end_pos_2, 
                    int port_3, int start_pos_3, int end_pos_3, int time) {
  int interval = 50;
  int curr_pos_1 = start_pos_1;
  int curr_pos_2 = start_pos_2;
  int curr_pos_3 = start_pos_3;
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
    set_servo_position(port_1, curr_pos_1);
    set_servo_position(port_2, curr_pos_2);
    set_servo_position(port_3, curr_pos_3);
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    curr_pos_3 += (float) {(end_pos_3 - start_pos_3)} / (float) {(time / interval)};
    msleep(50);
  }
    set_servo_position(port_1, end_pos_1);
    set_servo_position(port_2, end_pos_2);
    set_servo_position(port_3, end_pos_3);
}

void slow_servo_dual_mot(int port_1, int start_pos_1, int end_pos_1,
                         int port_2, int start_pos_2, int end_pos_2, 
                         int mot_port, int end_pos_3, int time) {
  int interval = 50;
  int curr_pos_1 = start_pos_1;
  int curr_pos_2 = start_pos_2;
  int start_pos_3 = get_motor_position_counter(mot_port);
  mav(mot_port, (end_pos_3 - start_pos_3) * 1000.0 / time);
  int cnt = 0;
  while (interval * cnt < time) {
    if ((end_pos_3 - get_motor_position_counter(mot_port)) * (end_pos_3 - start_pos_3) < 0) mav(mot_port, 0);
    set_servo_position(port_1, curr_pos_1);
    set_servo_position(port_2, curr_pos_2);
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    msleep(interval);
    ++cnt;
  }
    set_servo_position(port_1, end_pos_1);
    set_servo_position(port_2, end_pos_2);
  //mav(mot_port, (end_pos_3 - start_pos_3) * 1000.0 / time);
  //while ((end_pos_3 - get_motor_position_counter(mot_port)) * (end_pos_3 - start_pos_3) > 0) msleep(50);
}

void mot_to(int mot_port, int end_pos_3, int time) {
  int interval = 50;
  int start_pos_3 = get_motor_position_counter(mot_port);
  mav(mot_port, (end_pos_3 - start_pos_3) * 1000.0 / time);
  int cnt = 0;
  while (interval * cnt < time) {
    if ((end_pos_3 - get_motor_position_counter(mot_port)) * (end_pos_3 - start_pos_3) < 0) mav(mot_port, 0);
    msleep(interval);
    ++cnt;
  }
  //mav(mot_port, (end_pos_3 - start_pos_3) * 1000.0 / time);
  //while ((end_pos_3 - get_motor_position_counter(mot_port)) * (end_pos_3 - start_pos_3) > 0) msleep(50);
  mav(mot_port, 0);
}

void slow_servo_tri_mot(int port_1, int start_pos_1, int end_pos_1,
                         int port_2, int start_pos_2, int end_pos_2, 
                         int port_3, int start_pos_3, int end_pos_3, 
                         int mot_port, int end_pos_4, int time) {
  int interval = 50;
  int curr_pos_1 = start_pos_1;
  int curr_pos_2 = start_pos_2;
  int curr_pos_3 = start_pos_3;
  int start_pos_4 = get_motor_position_counter(mot_port);
  mav(mot_port, (end_pos_4 - start_pos_4) * 1000.0 / time);
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
    if ((end_pos_4 - get_motor_position_counter(mot_port)) * (end_pos_4 - start_pos_4) < 0) mav(mot_port, 0);
    set_servo_position(port_1, curr_pos_1);
    set_servo_position(port_2, curr_pos_2);
    set_servo_position(port_3, curr_pos_3);
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    curr_pos_3 += (float) {(end_pos_3 - start_pos_3)} / (float) {(time / interval)};
    msleep(50);
  }
    set_servo_position(port_1, end_pos_1);
    set_servo_position(port_2, end_pos_2);
    set_servo_position(port_3, end_pos_3);
  //while ((end_pos_4 - get_motor_position_counter(mot_port)) * (end_pos_4 - start_pos_4) > 0) msleep(50);
}

void slow_servo_quad(int port_1, int start_pos_1, int end_pos_1,
                         int port_2, int start_pos_2, int end_pos_2, 
                         int port_3, int start_pos_3, int end_pos_3, 
                         int port_4, int start_pos_4, int end_pos_4, int time) {
  int interval = 50;
  int curr_pos_1 = start_pos_1;
  int curr_pos_2 = start_pos_2;
  int curr_pos_3 = start_pos_3;
  int curr_pos_4 = start_pos_4;
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
    set_servo_position(port_1, curr_pos_1);
    set_servo_position(port_2, curr_pos_2);
    set_servo_position(port_3, curr_pos_3);
    set_servo_position(port_4, curr_pos_4);
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    curr_pos_3 += (float) {(end_pos_3 - start_pos_3)} / (float) {(time / interval)};
    curr_pos_4 += (float) {(end_pos_4 - start_pos_4)} / (float) {(time / interval)};
    msleep(50);
  }
    set_servo_position(port_1, end_pos_1);
    set_servo_position(port_2, end_pos_2);
    set_servo_position(port_3, end_pos_3);
    set_servo_position(port_4, end_pos_4);
}

int conv_left_arm(double pos) {
  return (pos * (double) {LEFT_ARM_UP - LEFT_ARM_DOWN} / (double) {1000}) + LEFT_ARM_DOWN;
}

int conv_right_arm(double pos) {
  return (pos * (double) {RIGHT_ARM_UP - RIGHT_ARM_DOWN} / (double) {1000}) + RIGHT_ARM_DOWN;
}

int get_arm_pos() {
  return (double) {get_servo_position(LEFT_ARM_PORT) - LEFT_ARM_DOWN} / (double) {LEFT_ARM_UP - LEFT_ARM_DOWN} * 1000;
}

int query_lift_arm() {
  printf("when query claw pos of %d, 0-1k scale of %d, %d\n", get_servo_position(CLAW_LIFT_PORT), (int) {(get_arm_pos() * (CLAW_LEVEL_UP - CLAW_LEVEL_DOWN) / 1000.0 + CLAW_LEVEL_DOWN) - get_servo_position(CLAW_LIFT_PORT)}, (int) {((get_arm_pos() * (CLAW_LEVEL_UP - CLAW_LEVEL_DOWN) / 1000.0 + CLAW_LEVEL_DOWN) - get_servo_position(CLAW_LIFT_PORT)) * 1000.0 / (CLAW_LIFT_UP - CLAW_LIFT_DOWN) + CLAW_LIFT_DOWN});
  return ((get_arm_pos() * (CLAW_LEVEL_UP - CLAW_LEVEL_DOWN) / 1000.0 + CLAW_LEVEL_DOWN) - get_servo_position(CLAW_LIFT_PORT)) * 1000.0 / (CLAW_LIFT_UP - CLAW_LIFT_DOWN) + CLAW_LEVEL_POS;
  //return 1000.0 / (CLAW_LIFT_UP - CLAW_LIFT_DOWN) * (get_servo_position(CLAW_LIFT_PORT) - CLAW_LIFT_DOWN);
}

int conv_lift_arm(int arm_pos, int lift_pos) {		// 0, 900
    printf("level for pos %d, %d = %d\n", arm_pos, lift_pos, (int) {(arm_pos * (CLAW_LEVEL_UP - CLAW_LEVEL_DOWN) / 1000.0 + CLAW_LEVEL_DOWN)});
  int tmp = (arm_pos * (CLAW_LEVEL_UP - CLAW_LEVEL_DOWN) / 1000.0 + CLAW_LEVEL_DOWN + (CLAW_LIFT_UP - CLAW_LIFT_DOWN) / 1000.0 * (lift_pos - CLAW_LEVEL_POS));
  return tmp < 10 ? 10 : tmp;
}

void move_lift(int pos, int time) {
  slow_servo(CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(get_arm_pos(), pos), time);
}

void move_arm(int arm_end_pos, int time) {
  slow_servo_dual(LEFT_ARM_PORT, get_servo_position(LEFT_ARM_PORT), conv_left_arm(arm_end_pos), 
                  RIGHT_ARM_PORT, get_servo_position(RIGHT_ARM_PORT), conv_right_arm(arm_end_pos), time);
}

void move_arm_drive_forward(int arm_end_pos, int time, int speed, int dist) {
  int interval = 80;
  int start_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int start_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int curr_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int curr_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int end_pos_1 = conv_left_arm(arm_end_pos);
  int end_pos_2 = conv_right_arm(arm_end_pos);
  set_create_distance(0);
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float distanceDrive = dist * 10 * CREATE_DRIVE_OFFSET;
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0 || get_create_distance() < distanceDrive) {
    if ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
        set_servo_position(LEFT_ARM_PORT, curr_pos_1);
        set_servo_position(RIGHT_ARM_PORT, curr_pos_2);
    }
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    if (get_create_distance() < distanceDrive) {
        create_drive_direct(left_speed, right_speed);
        if (get_create_distance() > distanceDrive * 0.8) create_drive_direct(left_speed / 2, right_speed / 2);
    } else create_stop();
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    msleep(80);
  }
  set_servo_position(LEFT_ARM_PORT, end_pos_1);
  set_servo_position(RIGHT_ARM_PORT, end_pos_2);
  create_stop();
}

void move_arm_drive_back(int arm_end_pos, int time, int speed, int dist) {
  int interval = 80;
  int start_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int start_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int curr_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int curr_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int end_pos_1 = conv_left_arm(arm_end_pos);
  int end_pos_2 = conv_right_arm(arm_end_pos);
  set_create_distance(0);
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float distanceDrive = -dist * 10 * CREATE_DRIVE_OFFSET;
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0 || get_create_distance() > distanceDrive) {
    if ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
        set_servo_position(LEFT_ARM_PORT, curr_pos_1);
        set_servo_position(RIGHT_ARM_PORT, curr_pos_2);
    }
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    if (get_create_distance() > distanceDrive) {
        create_drive_direct(-left_speed, -right_speed);
        if (get_create_distance() < distanceDrive * 0.8) create_drive_direct(-left_speed / 2, -right_speed / 2);
    } else create_stop();
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed - (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed + (offset / sensitivity);
    msleep(80);
  }
  set_servo_position(LEFT_ARM_PORT, end_pos_1);
  set_servo_position(RIGHT_ARM_PORT, end_pos_2);
  create_stop();
}

void move_arm_claw_lift_drive_back(int arm_end_pos, int claw_end_pos, int time, int speed, int dist) {
  int interval = 80;
  int start_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int start_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int start_pos_3 = get_servo_position(CLAW_LIFT_PORT);
  int curr_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int curr_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int curr_pos_3 = get_servo_position(CLAW_LIFT_PORT);
  int end_pos_1 = conv_left_arm(arm_end_pos);
  int end_pos_2 = conv_right_arm(arm_end_pos);
  int end_pos_3 = conv_lift_arm(arm_end_pos, claw_end_pos);
  set_create_distance(0);
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float distanceDrive = -dist * 10 * CREATE_DRIVE_OFFSET;
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0 || get_create_distance() > distanceDrive) {
    if ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
        set_servo_position(LEFT_ARM_PORT, curr_pos_1);
        set_servo_position(RIGHT_ARM_PORT, curr_pos_2);
        set_servo_position(CLAW_LIFT_PORT, curr_pos_3);
    }
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    curr_pos_3 += (float) {(end_pos_3 - start_pos_3)} / (float) {(time / interval)};
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    if (get_create_distance() > distanceDrive) {
        create_drive_direct(-left_speed, -right_speed);
        if (get_create_distance() < distanceDrive * 0.8) create_drive_direct(-left_speed / 2, -right_speed / 2);
    } else create_stop();
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed - (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed + (offset / sensitivity);
    msleep(80);
  }
  set_servo_position(LEFT_ARM_PORT, end_pos_1);
  set_servo_position(RIGHT_ARM_PORT, end_pos_2);
  set_servo_position(CLAW_LIFT_PORT, end_pos_3);
  create_stop();
}

void move_arm_claw_lift_drive_forward(int arm_end_pos, int claw_end_pos, int time, int speed, int dist) {
  int interval = 80;
  int start_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int start_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int start_pos_3 = get_servo_position(CLAW_LIFT_PORT);
  int curr_pos_1 = get_servo_position(LEFT_ARM_PORT);
  int curr_pos_2 = get_servo_position(RIGHT_ARM_PORT);
  int curr_pos_3 = get_servo_position(CLAW_LIFT_PORT);
  int end_pos_1 = conv_left_arm(arm_end_pos);
  int end_pos_2 = conv_right_arm(arm_end_pos);
  int end_pos_3 = conv_lift_arm(arm_end_pos, claw_end_pos);
  set_create_distance(0);
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float distanceDrive = dist * 10 * CREATE_DRIVE_OFFSET;
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  while ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0 || get_create_distance() < distanceDrive) {
    if ((end_pos_2 - curr_pos_2) * (end_pos_2 - start_pos_2) > 0) {
        set_servo_position(LEFT_ARM_PORT, curr_pos_1);
        set_servo_position(RIGHT_ARM_PORT, curr_pos_2);
        set_servo_position(CLAW_LIFT_PORT, curr_pos_3);
    }
    curr_pos_1 += (float) {(end_pos_1 - start_pos_1)} / (float) {(time / interval)};
    curr_pos_2 += (float) {(end_pos_2 - start_pos_2)} / (float) {(time / interval)};
    curr_pos_3 += (float) {(end_pos_3 - start_pos_3)} / (float) {(time / interval)};
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    if (get_create_distance() < distanceDrive) {
        create_drive_direct(left_speed, right_speed);
        if (get_create_distance() > distanceDrive * 0.8) create_drive_direct(left_speed / 2, right_speed / 2);
    } else create_stop();
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    msleep(80);
  }
  set_servo_position(LEFT_ARM_PORT, end_pos_1);
  set_servo_position(RIGHT_ARM_PORT, end_pos_2);
  set_servo_position(CLAW_LIFT_PORT, end_pos_3);
  create_stop();
}

void arm_claw_const(int arm_end_pos, int time) {			// 542, 1570, 290, 1300
  printf("FOR ARM_CLAW_CONST %d: %d, %d, %d, %d\n", arm_end_pos, conv_left_arm(arm_end_pos), conv_right_arm(arm_end_pos), query_lift_arm(), conv_lift_arm(arm_end_pos, query_lift_arm()));
  slow_servo_tri(LEFT_ARM_PORT, get_servo_position(LEFT_ARM_PORT), conv_left_arm(arm_end_pos), 
                  RIGHT_ARM_PORT, get_servo_position(RIGHT_ARM_PORT), conv_right_arm(arm_end_pos), 
                  CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(arm_end_pos, query_lift_arm()), time);
  msleep(30);
}

void move_arm_claw(int arm_end_pos, int claw_end_pos, int time) {
    slow_servo_tri(LEFT_ARM_PORT, get_servo_position(LEFT_ARM_PORT), conv_left_arm(arm_end_pos), 
                  RIGHT_ARM_PORT, get_servo_position(RIGHT_ARM_PORT), conv_right_arm(arm_end_pos), 
                   CLAW_PORT, get_servo_position(CLAW_PORT), claw_end_pos, time);
}

void move_arm_claw_lift(int arm_end_pos, int claw_end_pos, int time) {
    printf("FOR MOVE_ARM_CLAW_LIFT %d, %d\n", arm_end_pos, claw_end_pos);
    slow_servo_tri(LEFT_ARM_PORT, get_servo_position(LEFT_ARM_PORT), conv_left_arm(arm_end_pos), 
                  RIGHT_ARM_PORT, get_servo_position(RIGHT_ARM_PORT), conv_right_arm(arm_end_pos), 
                   CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(arm_end_pos, claw_end_pos), time);
}

void move_arm_claw_lift_claw(int arm_end_pos, int claw_end_pos, int claw_arm_end_pos, int time) {
    slow_servo_quad(LEFT_ARM_PORT, get_servo_position(LEFT_ARM_PORT), conv_left_arm(arm_end_pos), 
                  RIGHT_ARM_PORT, get_servo_position(RIGHT_ARM_PORT), conv_right_arm(arm_end_pos), 
                  CLAW_PORT, get_servo_position(CLAW_PORT), claw_end_pos, 
                   CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(arm_end_pos, claw_arm_end_pos), time);
}

void arm_claw_const_claw(int arm_end_pos, int claw_end_pos, int time) {
  slow_servo_quad(LEFT_ARM_PORT, get_servo_position(LEFT_ARM_PORT), conv_left_arm(arm_end_pos), 
                  RIGHT_ARM_PORT, get_servo_position(RIGHT_ARM_PORT), conv_right_arm(arm_end_pos), 
                  CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(arm_end_pos, query_lift_arm()), 
                  CLAW_PORT, get_servo_position(CLAW_PORT), claw_end_pos, time);
  msleep(30);
}

void close_claw() {
  set_servo_position(CLAW_PORT, CLAW_CLOSED);
  msleep(300);
}

void close_claw_slow(int tme) {
  slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), CLAW_CLOSED, tme);
  msleep(30);
}

void open_claw() {
  set_servo_position(CLAW_PORT, CLAW_OPEN);
  msleep(300);
}

void semi_claw() {
  set_servo_position(CLAW_PORT, CLAW_SEMI);
  msleep(300);
}

void narrow_claw() {
  set_servo_position(CLAW_PORT, CLAW_NARROW);
  msleep(300);
}

void open_claw_wide() {
  set_servo_position(CLAW_PORT, CLAW_OPEN_WIDE);
  msleep(300);
}

void fris_clamp() {
  set_servo_position(FRIS_PORT, FRIS_CLAMP);
  msleep(300);
}

void fris_rel() {
  set_servo_position(FRIS_PORT, FRIS_REL);
  msleep(300);
}

void fris_rest() {
  set_servo_position(FRIS_PORT, FRIS_REST);
  msleep(300);
}

void level_claw(int spd) {
  slow_servo(CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(get_arm_pos(), CLAW_LEVEL_POS), 250);
}

void back_claw(int spd) {
  slow_servo(CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(get_arm_pos(), CLAW_BACK_POS), 250);
}

void mid_claw(int spd) {
  slow_servo(CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), conv_lift_arm(get_arm_pos(), CLAW_MID_POS), 250);
}

void create_drive_close(int speed, int time) {
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float sensitivity = 5.3;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;
  int interval = 50;
  int start_pos = get_servo_position(CLAW_PORT);
  int end_pos = CLAW_CLOSED;
  int curr_pos = start_pos;
  set_servo_position(CLAW_PORT, start_pos);
  while ((end_pos - curr_pos) * (end_pos - start_pos) > 0) {
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(left_speed, right_speed);
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    curr_pos += (float) {(end_pos - start_pos)} / (float) {(time / interval)};
    if (curr_pos < 0) curr_pos = 0;
    set_servo_position(CLAW_PORT, curr_pos);
    msleep(50);
  }
  create_stop();
}

void create_follow_close(int speed, int time) {
  float diff_l = tc.blackValue - tc.whiteValue;
  float diff_r = tc.blackValueR - tc.whiteValueR;

  int interval = 50;
  int start_pos = get_servo_position(CLAW_PORT);
  int end_pos = CLAW_CLOSED;
  int curr_pos = start_pos;
  set_servo_position(CLAW_PORT, start_pos);
  while ((end_pos - curr_pos) * (end_pos - start_pos) > 0) {
    float right_ratio = ((analog(RIGHT_LIGHT_PORT) - tc.whiteValueR) / diff_r);
    float left_ratio = ((analog(LEFT_LIGHT_PORT) - tc.whiteValue)/diff_l);
    if(right_ratio > 1) right_ratio = 1;
    if(right_ratio < 0) right_ratio = 0;
    if(left_ratio > 1) left_ratio = 1;
    if(left_ratio < 0) left_ratio = 0;
    float d = (right_ratio - left_ratio) * 0.8;
    create_drive_direct(speed + d * speed, speed - d * speed);
    curr_pos += (float) {(end_pos - start_pos)} / (float) {(time / interval)};
    if (curr_pos < 0) curr_pos = 0;
    set_servo_position(CLAW_PORT, curr_pos);
    msleep(50);
  }
  create_stop();
}

void create_square_up(int speed, int time) {
  create_drive_direct(-speed * CREATE_LEFT_OFFSET, -speed * CREATE_RIGHT_OFFSET);
  msleep(time);
  create_stop();
}

int create_drive_back_diff_line(int speed) {
  create_drive_direct(-speed * CREATE_LEFT_OFFSET, -speed * CREATE_RIGHT_OFFSET);
  int itvl = 30;
  int tme_df = 0;
  while (analog(LEFT_LIGHT_PORT) < tc.blackValue - (tc.blackValue - tc.whiteValue) / 5) {
      if (tme_df != 0) tme_df += itvl;
      if (tme_df == 0 && analog(RIGHT_LIGHT_PORT) > tc.blackValue - (tc.blackValue - tc.whiteValue) / 5) tme_df += itvl;
      msleep(itvl);
  }
  create_stop();
  return tme_df;
}

void create_drive_forward(int speed, float dist) {
  set_create_distance(0);
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float distanceDrive = dist * 10 * CREATE_DRIVE_OFFSET;
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  while (get_create_distance() < distanceDrive) {							//while the robot has not driven enough distance
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(left_speed, right_speed);
    if (get_create_distance() > distanceDrive * 0.8) create_drive_direct(left_speed / 2, right_speed / 2);
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    msleep(80);
  }
  create_stop();															//stop create
}

void create_drive_forward_tme(int speed, int tme) {
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  int cnt = 0;
  while (cnt * 80 < tme) {							//while the robot has not driven enough distance
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(left_speed, right_speed);
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    ++cnt;
    msleep(80);
  }
  create_stop();															//stop create
}

void create_drive_touch(int speed) {
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts right speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;															//removes outliers, makes sure outliers don't mess up offset
  while (!get_create_lbump() && !get_create_rbump()) {							//while the robot has not driven enough distance
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(left_speed, right_speed);
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    msleep(80);
  }
  create_stop();															//stop create
}

void create_drive_back(int speed, float dist) {
  float left_speed = speed;
  float right_speed = speed;
  gyro_z();
  int tolerance = 340;
  double sensitivity = 5;
  float distanceDrive = dist * 10 * CREATE_DRIVE_OFFSET;
  float offset = 0;
  set_create_distance(distanceDrive);
  while(get_create_distance() > 0) {
    int val = gyro_z();
    val -= tc.GYRO_DEV;
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(-left_speed, -right_speed);
    offset += val;
    left_speed = speed - ((float){offset} / sensitivity);
    right_speed = speed + ((float){offset} / sensitivity);
    msleep(50);
  }
  create_stop();
}

void create_drive_forward_cliff(int speed) {
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  while (get_create_lcliff_amt() > (tc.whiteValueLCliff + tc.blackValueLCliff) / 2) {								//while the robot has not driven enough distance
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(left_speed, right_speed);
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    msleep(80);
  }
  create_stop();	
}

void create_drive_forward_rcliff(int speed) {
  int left_speed = speed;													//starts left speed at regular speed
  int right_speed = speed;													//starts left speed at regular speed
  float offset = 0;															//adds total change since start to calculate angle changed
  float sensitivity = 5;													//constant to convert change in gyro to change in motor speed
  gyro_z();																	//clears gyro sensor
  int tolerance = 350;														//removes outliers, makes sure outliers don't mess up offset
  while (get_create_rcliff_amt() > (tc.whiteValueRCliff + tc.blackValueRCliff) / 2) {								//while the robot has not driven enough distance
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(left_speed, right_speed);
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    msleep(80);
  }
  create_stop();	
}

void create_drive_back_cliff(int speed) {
  float left_speed = speed;
  float right_speed = speed;
  gyro_z();
  int tolerance = 340;
  double sensitivity = 5;
  float offset = 0;
  while(get_create_lcliff_amt() >  (tc.whiteValueLCliff + tc.blackValueLCliff) / 2) {
    int val = gyro_z();
    val -= tc.GYRO_DEV;
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(-left_speed, -right_speed);
    offset += val;
    left_speed = speed - ((float){offset} / sensitivity);
    right_speed = speed + ((float){offset} / sensitivity);
    msleep(50);
  }
  create_stop();
}

void create_drive_back_rcliff(int speed) {
  float left_speed = speed;
  float right_speed = speed;
  gyro_z();
  int tolerance = 340;
  double sensitivity = 5;
  float offset = 0;
  while(get_create_rcliff_amt() >  (tc.whiteValueRCliff + tc.blackValueRCliff) / 2) {
    int val = gyro_z();
    val -= tc.GYRO_DEV;
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(-left_speed, -right_speed);
    offset += val;
    left_speed = speed - ((float){offset} / sensitivity);
    right_speed = speed + ((float){offset} / sensitivity);
    msleep(50);
  }
  create_stop();
}

void create_drive_back_line(int speed) {
  float left_speed = speed;
  float right_speed = speed;
  gyro_z();
  int tolerance = 340;
  double sensitivity = 5;
  float offset = 0;
  while(analog(LEFT_LIGHT_PORT) < tc.blackValue - (tc.blackValue - tc.whiteValue) / 5) {
    int val = gyro_z();
    val -= tc.GYRO_DEV;
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(-left_speed, -right_speed);
    offset += val;
    left_speed = speed - ((float){offset} / sensitivity);
    right_speed = speed + ((float){offset} / sensitivity);
    msleep(50);
  }
  create_stop();
}

void create_drive_line(int speed) {
  float left_speed = speed;
  float right_speed = speed;
  gyro_z();
  int tolerance = 340;
  double sensitivity = 5;
  float offset = 0;
  while(analog(LEFT_LIGHT_PORT) < tc.blackValue - (tc.blackValue - tc.whiteValue) / 5) {
    float val = gyro_z();													//checks gyro change since last check
    val -= tc.GYRO_DEV;														//removes gyro deviation to make sure values are complete
    if (val > tolerance) val = tolerance;
    else if (val < -tolerance) val = -tolerance;
    create_drive_direct(left_speed, right_speed);
    offset += val;															//add newest change in gyro to the overall change
    left_speed = speed + (offset / sensitivity);					//change speeds based on the overall change
    right_speed = speed - (offset / sensitivity);
    msleep(80);
  }
  create_stop();
}

void create_right_line(int speed) {
  create_drive_direct(speed * CREATE_LEFT_OFFSET, -speed * CREATE_RIGHT_OFFSET);
  while(analog(LEFT_LIGHT_PORT) < tc.blackValue - (tc.blackValue - tc.whiteValue) / 5) {
    msleep(50);
  }
  create_stop();
}

void create_left_line(int speed) {
  create_drive_direct(-speed * CREATE_LEFT_OFFSET, speed * CREATE_RIGHT_OFFSET);
  while(analog(RIGHT_LIGHT_PORT) < tc.blackValueR - (tc.blackValueR - tc.whiteValueR) / 5) {
    msleep(50);
  }
  create_stop();
}

void create_turn_right(int speed, float degrees) {
  msleep(50);
  gyro_z();
  float offset = 0;
  float final_rot = -degrees * tc.GYRO_PER_ROT / 360;
  while(offset > final_rot) {
    create_drive_direct(speed * CREATE_LEFT_OFFSET, -speed * CREATE_RIGHT_OFFSET);
    if (offset < final_rot * 0.6) create_drive_direct(speed * CREATE_LEFT_OFFSET / 2, -speed * CREATE_RIGHT_OFFSET / 2);
    int val = gyro_z();
    offset += val - tc.GYRO_DEV;
    msleep(50);
  }
  create_stop();
  msleep(100);
}

void create_turn_right_accel(int speed, float degrees) {
  msleep(50);
  gyro_z();
  float offset = 0;
  float final_rot = -degrees * tc.GYRO_PER_ROT / 360;
  while(offset > final_rot) {
    create_drive_direct(speed * CREATE_LEFT_OFFSET, -speed * CREATE_RIGHT_OFFSET);
    if (offset > final_rot * 0.3) create_drive_direct(speed * CREATE_LEFT_OFFSET / 2, -speed * CREATE_RIGHT_OFFSET / 2);
    if (offset < final_rot * 0.7) create_drive_direct(speed * CREATE_LEFT_OFFSET / 2, -speed * CREATE_RIGHT_OFFSET / 2);
    int val = gyro_z();
    offset += val - tc.GYRO_DEV;
    msleep(50);
  }
  create_stop();
  msleep(100);
}

void create_turn_left_accel(int speed, float degrees) {
  msleep(50);
  gyro_z();
  float offset = 0;
  float final_rot = degrees * tc.GYRO_PER_ROT / 360;
  while(offset < final_rot) {
    create_drive_direct(-speed * CREATE_LEFT_OFFSET, speed * CREATE_RIGHT_OFFSET);
    if (offset < final_rot * 0.3) create_drive_direct(-speed * CREATE_LEFT_OFFSET / 2, speed * CREATE_RIGHT_OFFSET / 2);
    if (offset > final_rot * 0.7) create_drive_direct(-speed * CREATE_LEFT_OFFSET / 2, speed * CREATE_RIGHT_OFFSET / 2);
    int val = gyro_z();
    offset += val - tc.GYRO_DEV;
    msleep(50);
  }
  create_stop();
  msleep(100);
}

void create_turn_right_arc(int l_speed, int r_speed, float degrees) {
  gyro_z();
  float offset = 0;
  float final_rot = -degrees * tc.GYRO_PER_ROT / 360;
  while(offset > final_rot) {
    create_drive_direct(l_speed * CREATE_LEFT_OFFSET, r_speed * CREATE_RIGHT_OFFSET);
    int val = gyro_z();
    offset += val - tc.GYRO_DEV;
    msleep(50);
  }
  create_stop();
  msleep(100);
}

void create_turn_right_arc_gyro(int spd, int tme, float degrees) {
  gyro_z();
  float offset = 0;
  int tme_psd = 0;
  float final_rot = -degrees * tc.GYRO_PER_ROT / 360;
  while(offset > final_rot) {

    create_drive_direct(spd * CREATE_LEFT_OFFSET, spd * CREATE_RIGHT_OFFSET);
    int val = gyro_z();
    offset += val - tc.GYRO_DEV;
    tme_psd += 50;
    msleep(50);
  }
  create_stop();
  msleep(100);
}

void create_turn_right_arc_line(int l_speed, int r_speed) {
  gyro_z();
  float offset = 0;
  while(analog(LEFT_LIGHT_PORT) < tc.blackValue - 100) {
    create_drive_direct(l_speed * CREATE_LEFT_OFFSET, r_speed * CREATE_RIGHT_OFFSET);
    int val = gyro_z();
    offset += val - tc.GYRO_DEV;
    msleep(50);
  }
  create_stop();
  msleep(100);
}

void create_turn_left(int speed, float degrees) {
  msleep(50);
  gyro_z();
  float offset = 0;
  float final_rot = degrees * tc.GYRO_PER_ROT / 360;
  while(offset < final_rot) {
    create_drive_direct(-speed * CREATE_LEFT_OFFSET, speed * CREATE_RIGHT_OFFSET);
    if (offset > final_rot * 0.6) create_drive_direct(-speed * CREATE_LEFT_OFFSET / 2, speed * CREATE_RIGHT_OFFSET / 2);
    int val = gyro_z();
    offset += val - tc.GYRO_DEV;
    msleep(50);
  }
  create_stop();
  msleep(100);
}

int create_ET_right(int speed) {
  float rot = 0;
  create_drive_direct(speed * CREATE_LEFT_OFFSET, -speed * CREATE_RIGHT_OFFSET);
  int cnt = 0;
  while (cnt < 6) {
    if (analog(ET_PORT) >= 1200) ++cnt;
    int val = gyro_z();
    rot += val - tc.GYRO_DEV;
    msleep(10);
  }
  create_stop();
  return 90.0 - ((rot * 360.0 / tc.GYRO_PER_ROT) - 20.0);
}

int create_while_ET_left(int speed) {
  float rot = 0;
  create_drive_direct(-speed * CREATE_LEFT_OFFSET, speed * CREATE_RIGHT_OFFSET);
  int cnt = 0;
    int tmes = 0;
  while (cnt < 3) {
    if (analog(ET_PORT) >= 1900) cnt = (cnt - 1 < 0 ? 0 : cnt - 1);
    else ++cnt;
    int val = gyro_z();
    rot += val - tc.GYRO_DEV;
    msleep(30);
      ++tmes;
  }
  create_stop();
  return tmes;
}

void create_drive_ET(int speed) {
  create_drive_direct(speed * CREATE_LEFT_OFFSET, speed * CREATE_RIGHT_OFFSET);
  int cnt = 0;
  while (cnt < 3) {
    if (analog(ET_PORT) > 2000) cnt = (cnt - 1 < 0 ? 0 : cnt - 1);
    else ++cnt;
    msleep(30);
  }
  create_stop();
}

int create_ET_left(int speed) {
  float rot = 0;
  create_drive_direct(-speed * CREATE_LEFT_OFFSET, speed * CREATE_RIGHT_OFFSET);
  int cnt = 0;
  while (cnt < 6) {
    if (analog(ET_PORT) >= 1200) ++cnt;
    int val = gyro_z();
    rot += val - tc.GYRO_DEV;
    msleep(30);
  }
  create_stop();
  return 90.0 - ((rot * 360.0 / tc.GYRO_PER_ROT) - 20.0);
}

void bot_rel() {
  mav(CLAW_LIFT_PORT, 70);
  msleep(1200);
}

void create_line_follow(int speed, float tme) {
  int left_speed;
  int right_speed;
  int counter = 0;
  float offset = 120;
  while (counter * 10 < tme) {
    int right_val = analog(RIGHT_LIGHT_PORT);
    int left_val = analog(LEFT_LIGHT_PORT);
    int diff = ((double) {right_val - tc.whiteValueR} / (double) {tc.blackValueR - tc.whiteValueR} - 
                (double) {left_val - tc.whiteValue} / (double) {tc.blackValue - tc.whiteValue}) * offset;
    printf("%f, %f, %d, %d\n", (double) {right_val - tc.whiteValueR} / (double) {tc.blackValueR - tc.whiteValueR}, (double) {left_val - tc.whiteValue} / (double) {tc.blackValue - tc.whiteValue}, speed + diff, speed - diff);
    left_speed = speed + diff;
    right_speed = speed - diff;
    create_drive_direct(left_speed, right_speed);
    msleep(10);
    ++counter;
  }
    create_stop();
}

void create_line_follow_weak(int speed, float tme) {
  int left_speed;
  int right_speed;
  int counter = 0;
  float offset = 30;
  while (counter * 50 < tme) {
    int right_val = analog(RIGHT_LIGHT_PORT);
    int left_val = analog(LEFT_LIGHT_PORT);
    int diff = ((double) {right_val - tc.whiteValueR} / (double) {tc.blackValueR - tc.whiteValueR} - 
                (double) {left_val - tc.whiteValue} / (double) {tc.blackValue - tc.whiteValue}) * offset;
    left_speed = speed + diff;
    right_speed = speed - diff;
    create_drive_direct(left_speed, right_speed);
    msleep(50);
    ++counter;
  }
    create_stop();
}

void create_line_follow_ET(int speed) {
  int left_speed;
  int right_speed;
  float offset = 60;
  while (analog(ET_PORT) < HAY_VAL) {
    int right_val = analog(RIGHT_LIGHT_PORT);
    int left_val = analog(LEFT_LIGHT_PORT);
    int diff = ((double) {right_val - tc.whiteValueR} / (double) {tc.blackValueR - tc.whiteValueR} - 
                (double) {left_val - tc.whiteValue} / (double) {tc.blackValue - tc.whiteValue}) * offset;
    left_speed = speed + diff;
    right_speed = speed - diff;
    create_drive_direct(left_speed, right_speed);
  }
}

void create_line_follow_cliff(int speed) {
  int left_speed;
  int right_speed;
  float offset = 40;
  while (get_create_lcliff_amt() >  (tc.whiteValueLCliff + tc.blackValueLCliff) / 2) {
    int right_val = analog(RIGHT_LIGHT_PORT);
    int left_val = analog(LEFT_LIGHT_PORT);
    int diff = ((double) {right_val - tc.whiteValueR} / (double) {tc.blackValueR - tc.whiteValueR} - 
                (double) {left_val - tc.whiteValue} / (double) {tc.blackValue - tc.whiteValue}) * offset;
    left_speed = speed + diff;
    right_speed = speed - diff;
    create_drive_direct(left_speed, right_speed);
  }
}

void create_line_follow_rcliff(int speed) {
  int left_speed;
  int right_speed;
  float offset = 40;
  while (get_create_rcliff_amt() >  (tc.whiteValueRCliff + tc.blackValueRCliff) / 2) {
    int right_val = analog(RIGHT_LIGHT_PORT);
    int left_val = analog(LEFT_LIGHT_PORT);
    int diff = ((double) {right_val - tc.whiteValueR} / (double) {tc.blackValueR - tc.whiteValueR} - 
                (double) {left_val - tc.whiteValue} / (double) {tc.blackValue - tc.whiteValue}) * offset;
    left_speed = speed + diff;
    right_speed = speed - diff;
    create_drive_direct(left_speed, right_speed);
  }
}

void create_line_follow_touch(int speed) {
  int left_speed;
  int right_speed;
  float offset = 60;
  while (!get_create_lbump() && !get_create_rbump()) {
    int right_val = analog(RIGHT_LIGHT_PORT);
    int left_val = analog(LEFT_LIGHT_PORT);
    int diff = ((double) {right_val - tc.whiteValueR} / (double) {tc.blackValueR - tc.whiteValueR} - 
                (double) {left_val - tc.whiteValue} / (double) {tc.blackValue - tc.whiteValue}) * offset;
    left_speed = speed + diff;
    right_speed = speed - diff;
    create_drive_direct(left_speed, right_speed);
  }
}

void calc_dev() {
  printf("please keep robot still for 7 seconds\n press r_button when ready\n");
  while (!right_button()) msleep(50);
  printf("calculating...\n");
  int time = 7000;
  int interval = 100;
  double sum = 0;
  double i;
  gyro_z();
  for (i = 0; i < time / interval; ++i) {
    sum += gyro_z();
    msleep(interval);
  }
  tc.GYRO_DEV = sum / i;
  printf("average deviation of %d \n", (int) {tc.GYRO_DEV});
  printf("done\n");
}

void calc_turn() {
  gyro_z();
  tc.GYRO_PER_ROT = 0;
  create_drive_direct(-80, 80);
  int tme = 0;
  while (tme < 1000) {
    tc.GYRO_PER_ROT += gyro_z() - tc.GYRO_DEV;
    tme += 50;
    msleep(50);
  }
  int cnt = 0;
  while (cnt < 3) {
    tc.GYRO_PER_ROT += gyro_z() - tc.GYRO_DEV;
    cnt += (analog(RIGHT_LIGHT_PORT) < tc.blackValueR - (double) {tc.blackValueR - tc.whiteValueR} / 2.5 ? -1 : 1);
    if (cnt < 0) cnt = 0;
    msleep(25);
    if (cnt == 3) break;
    cnt += (analog(RIGHT_LIGHT_PORT) < tc.blackValueR - (double) {tc.blackValueR - tc.whiteValueR} / 2.5 ? -1 : 1);
    if (cnt < 0) cnt = 0;
    msleep(25);
  }
  tc.GYRO_PER_ROT -= 250;
  tc.GYRO_PER_ROT *= 2;
  create_stop();
}

void light_calib() {
  printf("please set sensors on white\n press r_button when ready\n");
  while (!right_button()) {
    msleep(50);
  }
  tc.whiteValue = analog(LEFT_LIGHT_PORT);
  tc.whiteValueR = analog(RIGHT_LIGHT_PORT);
  msleep(500);
  printf("please set sensors on black\n press r_button when ready\n");
  while (!right_button()) {
    msleep(50);
  }
  tc.blackValue = analog(LEFT_LIGHT_PORT);
  tc.blackValueR = analog(RIGHT_LIGHT_PORT);
  msleep(500);
  if (tc.blackValue < 2500|| tc.blackValueR < 2500 || tc.whiteValue > 300 || tc.whiteValueR > 300) {
    printf("Invalid Calibration, Bad values of: \n Left Black: %d \n Right Black: %d \n Left White: %d \n Right White: %d\n", tc.blackValue, tc.blackValueR, tc.whiteValue, tc.whiteValueR);
    printf("Press left button to redo, right button to override\n");
    while (!left_button() && !right_button()) msleep(50);
    if (left_button()) {
      while (left_button()) msleep(50);
      light_calib();
    }
    while (right_button()) msleep(50);
  }
}

void calib_cliff() {
  printf("Press the right button to calibrate the cliff sensors\n");
  while (!right_button()) msleep(50);
  while (right_button()) msleep(50);
  create_drive_direct(50, 50);
  tc.blackValueLCliff = 10000;
  tc.blackValueRCliff = 10000;
  tc.whiteValueLCliff = -1;
  tc.whiteValueRCliff = -1;
  int tme = 0;
  while (tme < 6000) {
    int l_val = get_create_lcliff_amt();
    int r_val = get_create_rcliff_amt();
    if (l_val < tc.blackValueLCliff) tc.blackValueLCliff = l_val;
    if (l_val > tc.whiteValueLCliff) tc.whiteValueLCliff = l_val;
    if (r_val < tc.blackValueRCliff) tc.blackValueRCliff = r_val;
    if (r_val > tc.whiteValueRCliff) tc.whiteValueRCliff = r_val;
    msleep(50);
    tme += 50;
  }
  create_stop();
}

void start_up() {
  create_connect();
  create_full();
  enable_servo(LEFT_ARM_PORT);
  enable_servo(RIGHT_ARM_PORT);
  enable_servo(CLAW_LIFT_PORT);
  enable_servo(CLAW_PORT);
  set_servo_position(LEFT_ARM_PORT, conv_left_arm(287));
  set_servo_position(RIGHT_ARM_PORT, conv_right_arm(287));
  set_servo_position(CLAW_LIFT_PORT, conv_lift_arm(287, CLAW_LEVEL_POS));
  open_claw_wide();

  move_arm(1000, 1500);
  light_calib();
  while (right_button() == 0) msleep(50);
  while (right_button() == 1) msleep(50);
  calc_dev();
  tc.GYRO_PER_ROT = 42700;
  
  calib_cliff();
    
  close_claw();
  msleep(1000);
  open_claw_wide();
  msleep(1000);
  move_arm_claw_lift(400, 0, 1000);

  msleep(1000);
  
  printf("CLICK RIGHT BUTTON FOR LIFTOFF =^..^= !!!\n");    
    
  while (right_button() == 0) msleep(50);
  while (right_button() == 1) msleep(50);
  
  //wait_for_light(LIGHT_START_PORT);
  shut_down_in(119.8);
}

TramCreate new_TramCreate() {
  TramCreate instance = {
    .motor = &motor,
    .mav = &mav,
    .ao = &ao,
    .off = &off,
    .get_motor_position_counter = &gmpc,
    .clear_motor_position_counter = &cmpc,
    .create_drive_direct = &create_drive_direct, 
    .get_create_rbump = &get_create_rbump, 
    .get_create_lbump = &get_create_lbump, 
    .enable_servo = &enable_servo,
    .disable_servo = &disable_servo,
    .enable_servos = &enable_servos,
    .disable_servos = &disable_servos,
    .get_servo_position = &get_servo_position,
    .set_servo_position = &set_servo_position,
    .digital = &digital,
    .analog = &analog,
    .analog10 = &analog10,
    .light_calib = &light_calib, 

    .slow_servo = &slow_servo, 
    .slow_servo_dual = &slow_servo_dual, 
    .create_drive_forward = &create_drive_forward, 
    .calc_dev = &calc_dev, 
    .start_up = &start_up, 
    .move_arm = &move_arm, 
    .move_arm_drive_forward = &move_arm_drive_forward, 
    .move_arm_drive_back = &move_arm_drive_back, 
    .move_arm_claw_lift_drive_forward = &move_arm_claw_lift_drive_forward, 
    .move_arm_claw_lift_drive_back = &move_arm_claw_lift_drive_back, 
    .arm_claw_const = &arm_claw_const, 
    .close_claw = &close_claw,
    .open_claw = &open_claw,
    .open_claw_wide = &open_claw_wide,
    .level_claw = &level_claw, 
    .back_claw = &back_claw,
    .mid_claw = &mid_claw, 
    .create_turn_left = &create_turn_left, 
    .create_drive_back = &create_drive_back, 
    .create_turn_right = &create_turn_right,
    .create_turn_right_accel = &create_turn_right_accel,
    .create_turn_left_accel = &create_turn_left_accel,
    .create_turn_right_arc = &create_turn_right_arc, 
    .create_turn_right_arc_line = &create_turn_right_arc_line, 
    .create_drive_close = &create_drive_close, 
    .create_square_up = &create_square_up, 
    .create_drive_touch = &create_drive_touch, 
    .narrow_claw = &narrow_claw, 
    .create_line_follow = &create_line_follow, 
    .create_follow_close = & create_follow_close, 
    .create_drive_back_line = &create_drive_back_line, 
    .create_drive_line = &create_drive_line, 
    .create_drive_forward_tme = &create_drive_forward_tme, 
    .create_right_line = &create_right_line, 
    .create_left_line = &create_left_line, 
    .semi_claw = &semi_claw,
    .create_line_follow_touch = &create_line_follow_touch, 
    .create_line_follow_weak = &create_line_follow_weak, 
    .create_line_follow_ET = &create_line_follow_ET, 
    .bot_rel = &bot_rel, 
    .fris_clamp = &fris_clamp, 
    .fris_rel = &fris_rel,
    .fris_rest = &fris_rest, 
    .create_ET_right = &create_ET_right, 
    .create_drive_ET = &create_drive_ET, 
    .create_while_ET_left = &create_while_ET_left, 
    .create_ET_left = &create_ET_left, 
    .create_drive_back_cliff = &create_drive_back_cliff, 
    .create_drive_back_rcliff = &create_drive_back_rcliff, 
    .create_drive_forward_cliff = &create_drive_forward_cliff, 
    .create_line_follow_cliff = &create_line_follow_cliff, 
    .create_line_follow_rcliff = &create_line_follow_rcliff, 
    .create_drive_forward_rcliff = &create_drive_forward_rcliff, 
    .close_claw_slow = &close_claw_slow, 
      .move_arm_claw = &move_arm_claw, 
      .move_arm_claw_lift = &move_arm_claw_lift, 
      .move_arm_claw_lift_claw = &move_arm_claw_lift_claw, 
      .arm_claw_const_claw = &arm_claw_const_claw, 
      .move_lift = &move_lift, 
      .create_drive_back_diff_line = &create_drive_back_diff_line, 
  };
  return instance;
}