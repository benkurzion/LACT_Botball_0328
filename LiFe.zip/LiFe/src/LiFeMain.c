#include "LiFeDrive.h"
#include <math.h>

int tme_init;

double calc_ET_dist() {
  double avg_val = 0;
  double chcks = 100;
  int tme = 800;
  int cnt = 0;
  for (cnt = 0; cnt < chcks; ++cnt) {
    int val = analog(ET_PORT);
    if (val < 1500) {
      --chcks;
      --cnt;
      msleep(tme / chcks);
      continue;
    }
    avg_val += analog(ET_PORT);
    msleep(tme / chcks);
  }
  avg_val /= chcks;
  double best_val = 2600.0;
  double ret = (best_val - avg_val) / 120.0;
    printf("%d, %d\n", (int) {avg_val}, (int) {ret});
  return ret;
}

void TramCreateMain(int ste) {					// 0: Seeding
    											// 1: Pipe in Double Seeding/Elim
    											// 2: Pipe Out Double Seeding/Elim
  printf("running TramCreateMain\n");
  tc = new_TramCreate();
  tc.start_up();
    //tc.create_turn_right(200, 90);			// 542, 1570, 290, 1300
  int tme_init = seconds();
    
  tc.level_claw(300);
  
  tc.arm_claw_const(0, 400);
    
  if (ste == 2) tc.create_drive_forward_rcliff(250);
  else tc.create_drive_forward_cliff(250);
  tc.close_claw();
  tc.move_arm_drive_forward(300, 300, 350, 10.5);
  if (ste == 2) tc.create_turn_left(200, 90);
  else tc.create_turn_right(200, 90);
  tc.move_arm_claw(0, CLAW_OPEN_WIDE, 500);
  tc.move_arm(300, 300);
  msleep(200);
  tc.create_square_up(150, 700); 
  tc.move_arm(0, 300);
  tc.create_line_follow(400, 500);
  tc.create_line_follow_weak(400, 500);
  create_drive_direct(100, 100);
  tc.close_claw_slow(300);
  create_stop();
    
  tc.move_arm_claw_lift_drive_forward(1000, 780, 700, 300, 8);
  if (ste == 2) tc.create_drive_forward_rcliff(200);
  else tc.create_drive_forward_cliff(200);
  tc.create_drive_forward(200, 4);
  if (ste == 2) tc.create_turn_left(200, 90);
  else tc.create_turn_right(200, 90);
  msleep(100);
    
  create_drive_direct(120, 120);
  tc.slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), (get_servo_position(CLAW_PORT) * 2 + CLAW_OPEN_WIDE) / 3, 250);
  create_drive_direct(210, 210);
  tc.slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), CLAW_OPEN_WIDE, 480);
  create_stop(); 
  tc.close_claw();
  tc.create_drive_back(300, 2);
  tc.create_drive_back_cliff(180);
  tc.create_drive_back(300, 11);
  //tc.create_drive_back_line(180);
  //tc.create_drive_back(200, 3);
  tc.open_claw();
  set_servo_position(CLAW_LIFT_PORT, 10);
  msleep(300);
  tc.close_claw();
  tc.create_drive_forward(300, 1);

  if (ste == 2) {
    tc.create_turn_left(200, 45);
    tc.create_drive_forward(300, 20);
    tc.create_turn_left(200, 20);
    tc.create_left_line(60);
    tc.create_turn_right(50, 2);
  } else {
    tc.create_turn_right(200, 45);
    tc.create_drive_forward(300, 20);
    tc.create_turn_right(200, 20);
    tc.create_right_line(60);
    tc.create_turn_left(50, 2);
  }
  if (ste != 0) {
    tc.move_arm_claw_lift(1000, 900, 1000);
    tc.open_claw_wide();
    tc.create_line_follow(130, 800);
    tc.create_line_follow_weak(130, 1000);
    if (ste == 2) tc.create_turn_left(200, 90);
    else tc.create_turn_right(200, 90);
    tc.create_drive_forward(300, 27);
  } else {
    tc.create_line_follow(370, 1500);
    tc.create_turn_right(200, 90);
    tc.create_drive_forward(300, 27);
    tc.create_turn_right(200, 90);
    tc.create_square_up(400, 400);
    tc.create_square_up(220, 600);
    tc.create_drive_forward(300, 19);
    tc.create_turn_left(200, 90);
    tc.create_drive_touch(200);
    tc.open_claw_wide();

    tc.move_arm_claw_lift(0, CLAW_LEVEL_POS, 700);
    msleep(100);
    tc.close_claw_slow(300);
    msleep(100);
    tc.arm_claw_const(500, 400);
    tc.create_drive_back(350, 43);
    tc.arm_claw_const(100, 400);
    tc.open_claw_wide();
    tc.arm_claw_const(600, 400);

    tc.create_drive_forward(300, 2);
    tc.create_turn_right(200, 70);
    tc.create_right_line(40);
    tc.create_line_follow(300, 400);
    tc.create_line_follow_weak(300, 200);
    tc.create_line_follow_weak(150, 700);
    set_servo_position(CLAW_PORT, CLAW_CLOSED);
    tc.create_turn_left(200, 90);

    tc.create_drive_forward(300, 27);
    tc.create_drive_touch(100);

    if (tc.create_while_ET_left(50) > 4) tc.create_turn_right(70, 11);

    tc.open_claw_wide();
    tc.create_drive_back(150, 3);
    tc.arm_claw_const(50, 400);
    tc.create_drive_forward(100, 2);
    tc.arm_claw_const(0, 100);
    msleep(100);
    tc.close_claw_slow(300);
    msleep(100);
    tc.arm_claw_const(500, 400);
    tc.create_drive_back(350, 40);
    tc.create_turn_left(100, 10);
    tc.arm_claw_const(100, 400);
    tc.open_claw_wide();
    tc.move_arm_claw_lift(500, CLAW_LEVEL_POS + 100, 400);
    tc.create_turn_right(100, 36);
    tc.move_arm_claw_lift_drive_forward(1000, 900, 400, 350, 32.5);
    tc.create_turn_left(200, 20);
  }
  if (ste == 2) tc.create_ET_left(40);
  else tc.create_ET_right(40);
  double d = calc_ET_dist();
  if (d > 0) tc.create_drive_forward(40, d);
  else tc.create_drive_back(40, -d);
  tc.move_arm_claw_lift(860, CLAW_LEVEL_POS, 400);
    //tc.create_drive_forward(100, 2);
  tc.slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), 1100, 700);
      
  tc.move_arm_claw_lift_drive_back(1000, 1000, 300, 350, 14);
  if (ste == 0) tc.create_turn_left(80, 4);
  else if (ste == 1) tc.create_turn_left(80, 16);
  else tc.create_turn_right(80, 16);
  //tc.create_square_up(500, 1300);
  //tc.create_square_up(300, 1200);
  tc.create_square_up(500, 1700);  
  //tc.create_square_up(300, 200);
  create_drive_direct(-100, -100);
  tc.slow_servo(CLAW_LIFT_PORT, get_servo_position(CLAW_LIFT_PORT), 1100, 1000);
  create_stop();
  printf("time taken: %d\n", (int) {seconds() - tme_init});
    
  tc.create_drive_forward(300, 6);

  if (ste == 2) {
    tc.create_turn_right(150, 90);
    tc.create_drive_back_rcliff(150);
  } else {
    tc.create_turn_left(150, 90);
    tc.create_drive_back_cliff(150);
  }
  
  
  tc.create_drive_back(350, 18);
  if (ste == 2) tc.create_turn_left(200, 90);
  else tc.create_turn_right(200, 90);
  tc.create_square_up(300, 800);
  tc.create_square_up(100, 500);
  
  if (ste != 0) while (seconds() - tme_init < 60) msleep(50);
    
  //tc.create_drive_forward(200, 1);
  //tc.create_drive_forward(200, 1.5);
  //tc.create_drive_forward(200, 1);
  create_drive_direct(120, 120);
  tc.move_lift(700, 500);
  //tc.create_drive_forward(200, 2);
  tc.slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), CLAW_OPEN_WIDE, 800);
  tc.open_claw_wide();
  tc.move_arm_claw_lift(1000, 1000, 500);
  tc.create_drive_forward_cliff(150);
    
    //tc.create_drive_back(150, 4);
    tc.create_line_follow_ET(200);
    create_stop();
    tc.create_drive_back(300, 11);
    if (ste == 2) {
      tc.create_turn_left(200, 70);
      tc.create_left_line(40);
    } else {
      tc.create_turn_right(200, 70);
      tc.create_right_line(40);
    }
    tc.move_arm_claw_lift_claw(0, CLAW_OPEN_WIDE, CLAW_LEVEL_POS, 1000);
    tc.create_line_follow(300, 800);
    tc.create_line_follow_weak(300, 600);
    tc.create_line_follow_weak(100, 1000);
    tc.close_claw_slow(300);
    tc.move_arm_claw_lift(1000, 820, 1000);
    tc.create_drive_back(300, 11);
    tc.create_drive_back(300, 1.5);
    tc.create_turn_left(200, 200);
    tc.create_right_line(100);
    tc.create_turn_left(100, 5);
  tc.create_line_follow(250, 400);
  if (ste == 2) tc.create_line_follow_cliff(150);
  else tc.create_line_follow_rcliff(150);
  tc.create_drive_forward(250, 4);
  if (ste == 2) tc.create_turn_left(200, 90);
  else tc.create_turn_right(200, 90);
  msleep(200);
    tc.create_drive_back(200, 7);
    msleep(100);
    
  create_drive_direct(120, 120);
  tc.slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), (get_servo_position(CLAW_PORT) * 2 + CLAW_OPEN_WIDE) / 3, 200);
  create_drive_direct(210, 210);
  tc.slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), CLAW_OPEN_WIDE, 300);
  create_stop();
    tc.create_drive_back(300, 20);
    //tc.create_turn_right(60, 3);

    tc.move_arm_claw_lift_claw(110, CLAW_OPEN_WIDE, CLAW_LEVEL_POS + 70, 700);
  tc.create_line_follow_cliff(150);
    tc.create_line_follow_weak(120, 200);
    tc.slow_servo(CLAW_PORT, get_servo_position(CLAW_PORT), 1434, 400);
    //tc.open_claw_wide();
    //tc.move_arm(530, 1000);
    //tc.arm_claw_const(140, 1000);
    tc.create_line_follow_weak(120, 400);
    //tc.create_line_follow(120, 800);
    create_stop();
    msleep(300);
    tc.semi_claw();
    msleep(100);
    tc.move_lift(CLAW_LEVEL_POS + 110, 600);
    //tc.create_drive_back(300, 13);
    tc.create_drive_back(300, 12);
    if (ste == 2) tc.create_turn_left_accel(200, 40);
    else tc.create_turn_right_accel(200, 40);
    msleep(500);
    tc.open_claw();
    //tc.move_arm_claw(500, CLAW_LEVEL_POS, 600);
    tc.move_arm_claw_lift(1000, 850, 1000);
    if (ste == 2) tc.create_turn_right(200, 40);
    else tc.create_turn_left(200, 40);
    tc.create_line_follow(350, 800);
    tc.create_line_follow_weak(350, 700);

    tc.create_drive_back(350, 40);
    tc.move_arm_claw_lift_claw(160, CLAW_CLOSED, CLAW_LEVEL_POS, 1200);
    tc.create_line_follow_weak(200, 700);
    create_stop();
    tc.open_claw();
    tc.create_line_follow_weak(200, 1300);
    create_stop();
    tc.close_claw();
    tc.arm_claw_const(290, 1000);
    tc.create_drive_back(350, 42);
    //tc.back_claw(400);
    tc.move_arm(600, 800);
    tc.level_claw(300);
    tc.move_arm_claw_lift(1000, 900, 700);
    //tc.create_line_follow(260, 1600);
    tc.create_line_follow_weak(260, 600);
    tc.create_turn_right(50, 10);
    tc.create_drive_forward(300, 10);
    tc.create_turn_left(50, 15);
    create_stop();
    tc.move_lift(600, 600);
    printf("seconds taken: %d\n", (int) {seconds() - tme_init});

tc.disable_servos();
  create_safe();
  msleep(200);
  create_disconnect();
}
