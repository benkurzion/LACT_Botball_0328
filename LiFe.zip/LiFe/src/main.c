#include <kipr/botball.h>
#include <math.h>

#include "LiFeDrive.h"

#define ROBOT_COUNT 10

int menu_size;
int current_point_position = 0;
const char *names[ROBOT_COUNT];

int min(int a, int b) {if (a < b) return a; else return b;}
int max(int a, int b) {if (a > b) return a; else return b;}

void print_screen() {
    if (current_point_position < 0) current_point_position = 0;
    if (current_point_position >= menu_size) current_point_position = menu_size - 1;
    int i;
    for (i = 0; i < 50; ++i) printf("\n");
    printf("press left button to go up, press right button to go down, a button to select, c button to go back\n\n");
    for (i = max(0, current_point_position - 5); i <= min(menu_size - 1, max(0, current_point_position - 5) + 7); ++i) {
        printf(names[i]); if (current_point_position == i) printf(" <-");
        printf("\n");
    }
}

int main() {
    while (1) {
        menu_size = 4;
        names[0] = "Run Seeding"; names[1] = "Run Pipe In Side, 2 Bins";
        names[2] = "Run Pipe Out Side, 2 Bins";  names[3] = "Check Arm";
        int cont = 1;
        while (cont) {
            print_screen();
            while (!left_button() && !right_button() && !a_button() && !c_button()) msleep(50);
            if (left_button()) --current_point_position;
            if (right_button()) ++current_point_position;
            if (a_button()) {
                while (a_button()) msleep(50);
                cont = 0;
            }
            while (left_button() || right_button() || b_button()) msleep(50);
        }
        printf("selected %s\n", names[current_point_position]);
        if (current_point_position == 0) {
            TramCreateMain(0);
            break;
        }
        if (current_point_position == 1) {
            TramCreateMain(1);
            break;
        }
        if (current_point_position == 2) {
            TramCreateMain(2);
            break;
        } 
        if (current_point_position == 3) {
            CheckArm();
        }
        printf("ended\n");
    }

    return 0;
}
