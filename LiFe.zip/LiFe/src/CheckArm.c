#include "LiFeDrive.h"
#include <math.h>

void CheckArm() {
    int i; for (i = 0; i < 50; ++i) printf("\n");
    tc = new_TramCreate();
    tc.enable_servo(LEFT_ARM_PORT); tc.enable_servo(RIGHT_ARM_PORT);
    tc.set_servo_position(LEFT_ARM_PORT, LEFT_ARM_DOWN); tc.set_servo_position(RIGHT_ARM_PORT, RIGHT_ARM_DOWN);
    msleep(2000);
    //tc.arm_claw_const(1000, 4000);
    //tc.arm_claw_const(0, 4000);
    
    int pos = 0;
    while (1) {
        if (left_button()) ++pos;
        else if (right_button()) --pos;
        if (pos < 0) pos = 0; if (pos > 1000) pos = 1000;
    	msleep(3);
        printf("at position %d\n", pos);
        if (b_button()) {
        	tc.arm_claw_const(pos, 2000);
        }
    }
}
