#include <kipr/botball.h>

typedef struct TramCreate {
    #define CREATE_DRIVE_OFFSET 1
    #define CLAW_LIFT_PORT 3
    #define CLAW_PORT 2
    #define CLAW_OPEN 1500
    #define CLAW_OPEN_WIDE 1860
    #define CLAW_CLOSED 950
    #define CLAW_SEMI 1020
    #define CLAW_NARROW 1330
    #define ET_PORT 0
    #define HAY_VAL 2900
    #define LEFT_ARM_PORT 0
    #define RIGHT_ARM_PORT 1
    #define RIGHT_ARM_UP 320
    #define RIGHT_ARM_DOWN 1570
    #define LEFT_ARM_UP 1886
    #define LEFT_ARM_DOWN 542
    #define CLAW_LEVEL_POS 500
    #define CLAW_LEVEL_UP 1820
    #define CLAW_LEVEL_DOWN 570
    #define CLAW_LIFT_UP 0
    #define CLAW_LIFT_DOWN 2030
    #define CLAW_LOW_POS 0
    #define CLAW_BACK_POS 1000
    #define CLAW_MID_POS 100
    //#define CLAW_LEVEL_UP 
    //#define CLAW_LOW_POS 0
    //int LAZY_CLAW_OFF;
    //#define CLAW_MID_POS -30 - 40
    //#define CLAW_BACK_POS -940
    //#define CLAW_LEVEL_POS -380 - 40
    #define CREATE_RIGHT_OFFSET 1
    #define CREATE_LEFT_OFFSET 1
    #define LEFT_LIGHT_PORT 4
    #define RIGHT_LIGHT_PORT 5					//1088, 973
    #define FRIS_PORT 3
    #define FRIS_REL 300
    #define FRIS_CLAMP 1650
    #define FRIS_REST 2030
  
    #define LIGHT_START_PORT 1
  
    double GYRO_PER_ROT;
	double GYRO_DEV;
    int fris_claw_pos;
    int blackValue;
    int whiteValue;
    int blackValueR;
    int whiteValueR;
    int blackValueLCliff;
    int whiteValueLCliff;
    int blackValueRCliff;
    int whiteValueRCliff;
        
    void (*motor)(int motor, int percent);
    int (*mav)(int motor, int velocity);
    void (*ao)();
    void (*off)(int motor);
    int (*get_motor_position_counter)(int motor);
    void (*clear_motor_position_counter)(int motor);
    void (*enable_servo)(int port);
    void (*disable_servo)(int port);
    void (*enable_servos)();
	void (*disable_servos)();
    int (*get_servo_position)(int port);
    void (*set_servo_position)(int port, int position);
    void (*create_drive_direct)(int left_speed, int right_speed);
    int (*get_create_lbump)();
    int (*get_create_rbump)();
    int (*digital)(int port);
	int (*analog)(int port);
	int (*analog10)(int port);
    
    void (*slow_servo)(int port, int start_pos, int end_pos, int time);
	void (*slow_servo_dual)(int port_1, int start_pos_1, int end_pos_1, int port_2, int start_pos_2, int end_pos_2, int time);
	void (*create_drive_forward)(int speed, float dist);
    void (*create_drive_back)(int speed, float dist);
    void (*create_drive_back_line)(int speed);
    void (*calc_dev)();
    void (*start_up)();
    void (*move_arm)(int arm_end_pos, int time);
    void (*move_arm_drive_forward)(int arm_end_pos, int time, int spd, int dist);
    void (*move_arm_drive_back)(int arm_end_pos, int time, int spd, int dist);
    void (*move_arm_claw_lift_drive_back)(int arm_end_pos, int claw_end_pos, int time, int spd, int dist);
    void (*move_arm_claw_lift_drive_forward)(int arm_end_pos, int claw_end_pos, int time, int spd, int dist);
    void (*arm_claw_const)(int arm_end_pos, int time);
    void (*move_arm_claw)(int arm_end_pos, int claw_end_pos, int time);
    void (*move_arm_claw_lift)(int arm_end_pos, int claw_end_pos, int time);
    void (*move_arm_claw_lift_claw)(int arm_end_pos, int claw_end_pos, int claw_arm_end_pos, int time);
    void (*arm_claw_const_claw)(int arm_end_pos, int claw_end_pos, int time);
    void (*close_claw)();
    void (*open_claw)();
    void (*open_claw_wide)();
    void (*level_claw)(int spd);
    void (*back_claw)(int spd);
    void (*create_turn_left)(int speed, float degrees);
    void (*create_turn_right)(int speed, float degrees);
    void (*create_turn_right_accel)(int speed, float degrees);
    void (*create_turn_left_accel)(int speed, float degrees);
    void (*create_drive_close)(int speed, int time);
    void (*create_square_up)(int speed, int time);
    void (*create_drive_touch)(int speed);
    void (*narrow_claw)();
    void (*create_turn_right_arc)(int l_speed, int r_speed, float degrees);
    void (*create_line_follow)(int speed, float tme);
    void (*create_line_follow_weak)(int speed, float tme);
    void (*create_line_follow_cliff)(int speed);
    void (*create_line_follow_rcliff)(int speed);
    void (*create_follow_close)(int speed, int tme);
    void (*create_drive_line)(int speed);
    void (*light_calib)();
    void (*create_drive_forward_tme)(int speed, int tme);
    void (*mid_claw)(int spd);
    void (*create_right_line)(int speed);
    void (*create_left_line)(int speed);
    void (*semi_claw)();
    void (*create_line_follow_touch)(int speed);
    void (*create_line_follow_ET)(int speed);
    void (*bot_rel)();
    void (*fris_clamp)();
    void (*fris_rel)();
    void (*fris_rest)();
    int (*create_ET_right)(int speed);
    int (*create_while_ET_left)(int speed);
    int (*create_ET_left)(int speed);
    void (*create_drive_ET)(int speed);
    void (*create_drive_back_cliff)(int speed);
    void (*create_drive_back_rcliff)(int speed);
    void (*create_turn_right_arc_line)(int l_speed, int r_speed);
    void (*create_drive_forward_cliff)(int speed);
    void (*create_drive_forward_rcliff)(int speed);
    void (*close_claw_slow)(int tme);
    void (*move_lift)(int pos, int time);
    int (*create_drive_back_diff_line)(int spd);
} TramCreate;

extern TramCreate new_TramCreate();

void TramCreateMain(int ste);
void CheckArm();

TramCreate tc;
