#ifndef SORT_H
#define SORT_H

//define variable for stopping sort while loop, probably will be done differently
int stopSort;
//define variables used for counting poms stored
int blue_count , green_count , orange_count , pink_count;

int find_color();
int think(int);
void sort_colors();

#endif